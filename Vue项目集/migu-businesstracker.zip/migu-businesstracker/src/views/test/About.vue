<template>
<div>
About Page!123123123
</div>
</template>


<script>

export default {
  name: 'Login',
  data () {
    return {
      msg: "i'm login page",
      userName: '111',
      password: ''
    }
  }
}

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
