var urIConfig = {
  'defaultApi': 'http://183.192.162.200:30040',
  'businesstrackerApi': 'http://183.192.162.200:30040',
  'adminApi': 'http://183.192.162.200:30040',
  'resourceApi': 'http://183.192.162.200:30040',
  'uploadApi': 'http://183.192.162.200:30040',
  'filePrefix': 'http://183.192.162.200:30040/upload/file/',
  'imagePrefix': 'http://183.192.162.200:30040/upload/image/',
  'avatarImagePrefix': 'http://183.192.162.200:30030/static/upload/image/avatar/',
};