var urIConfig = {
    'defaultApi': 'http://localhost:30040',
    'businesstrackerApi': 'http://localhost:30040',
    'adminApi': 'http://localhost:30040',
    'resourceApi': 'http://localhost:30040',
    'uploadApi': 'http://localhost:30040',
    'filePrefix': 'http://localhost:8080/static/upload/file/',
    'imagePrefix': 'http://localhost:8080/static/upload/image/',
    'avatarImagePrefix': 'http://localhost:8080/static/upload/image/avatar/',
};